namespace codexplorers.SCRUMPoker {
	public enum PokerCard {
    c0 = 0,
	c1 = 1,
	c2 = 2,
	c3 = 3,
	c5 = 5,
	c8 = 8,
	c13 = 13,
	cCoffee = -1
	}
}
