using System;
using System.Collections.Generic;
using System.Text;
using System.Configuration;
using System.CodeDom.Compiler;
using Microsoft.CSharp;
using System.Reflection;
using System.Diagnostics;

namespace SourceCodeManager
{
    public class Runtime
    {
        #region Execute
        /// <summary>
        /// Assumes that codeContainer.CompiledAssembly is populated
        /// via the Registration.Update method.
        /// This method will execute the desired classname.method with
        /// the parameters passed in and return an object.
        /// </summary>
        public object Execute(CodeContainer codeContainer,
                              string methodName,
                              object[] parameters)
        {

            object assemblyInstance = null;
            MethodInfo methodInformation = null;
            Type type = null;
            string qualifiedClassName = "";

            try
            {

                qualifiedClassName += codeContainer.NameSpace + ".";
                qualifiedClassName += codeContainer.ClassName;
                assemblyInstance = codeContainer.CompiledAssembly.CreateInstance(
                                                                  qualifiedClassName,
                                                                  false
                                                                  );
                type = assemblyInstance.GetType();
                methodInformation = type.GetMethod(methodName);
                return methodInformation.Invoke(assemblyInstance, parameters);

            }
            catch (Exception) { throw; }
            return null;

        }
        #endregion

    }
}
