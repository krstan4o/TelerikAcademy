using System;
using System.Collections.Generic;
using System.Text;
using System.Diagnostics; 

namespace SourceCodeManager
{
    public class Registration
    {
        public static List<CodeContainer> CodeContainers = new List<CodeContainer>();

        #region Update
        /// <summary>
        /// Manages the static List CodeContainers.   
        /// Compare this code with that which is set in
        /// our static List by the UniqueKey.
        /// If not found, compile and add.
        /// If found but source code is different, delete, compile, and add.
        /// If found and source code is the same, grab reference to
        /// previously compiled assembly.
        /// The codeContainer passed in will always have its .CompiledAssembly
        /// property populated after this method (Update) is called.
        /// </summary>
        public static void Update(CodeContainer codeContainer)
        {
            CodeContainer existingCode = null;
            SourceCodeManager.Compiler compiler = null;
            System.Reflection.Assembly assembly = null;

            try
            {

                existingCode = GetCodeContainer(codeContainer.UniqueKey);

                if (existingCode != null)
                {
                    if (existingCode.SourceCode != codeContainer.SourceCode)
                    {
                        Delete(existingCode);
                        existingCode = null;
                    }
                }

                if (existingCode == null)
                {
                    compiler = new SourceCodeManager.Compiler();
                    assembly = compiler.Compile(codeContainer.SourceCode);
                    codeContainer.CompiledAssembly = assembly;
                    CodeContainers.Add(codeContainer);
                    return;
                }

                codeContainer.ClassName = existingCode.ClassName;
                codeContainer.NameSpace = existingCode.NameSpace;
                codeContainer.CompiledAssembly = existingCode.CompiledAssembly;
              
            }
            catch (Exception) { throw; }
        }
        #endregion

        #region Delete
        /// <summary>
        /// Remove this code container object from our static List.
        /// </summary>
        public static void Delete(CodeContainer code)
        {
            try
            {
                code.CompiledAssembly = null;
                CodeContainers.Remove(code);
            }
            catch (Exception) { throw; }
        }
        #endregion

        #region Get Code Container
        /// <summary>
        /// Get a reference to the static List CodeContainer object
        /// via its UniqueKey property.
        /// </summary>
        public static CodeContainer GetCodeContainer(string uniqueKey)
        {
            try
            {

                return CodeContainers.Find(delegate(CodeContainer record)
                             {
                                 return int.Equals(record.UniqueKey,
                                                   uniqueKey);
         
                             });

            }
            catch (Exception) { throw; }
        }
        #endregion

    }
}
