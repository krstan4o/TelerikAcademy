using System;
using System.Collections.Generic;
using System.Text;
using System.Web;
using System.IO;

namespace SourceCodeManager
{
    public class Diagnostics
    {

        #region Get Report In Html Table Format
        /// <summary>
        /// Simple Html output of assemblies currently loaded into
        /// the application domain.
        /// </summary>
        public static string GetReportInHtmlTableFormat(string serverIPAddress,
                                                        bool showSystemNameSpaces)
        {
            StringBuilder sb = new StringBuilder();
            System.Reflection.Assembly[] assemblies = null;

            try
            {
                 
                sb.Append("<table border=\"0\" cellpadding=\"1\" cellspacing=\"1\">");
                sb.Append("<tr>");
                sb.Append("<td align=\"left\" width=\"50\">");
                sb.Append("<b>Server</b>");
                sb.Append("</td>");
                sb.Append("<td align=\"left\"><b>");
                sb.Append(serverIPAddress);
                sb.Append("</b></td>");
                sb.Append("</tr>");

                assemblies = System.AppDomain.CurrentDomain.GetAssemblies();

                for (int i = 0; i < assemblies.Length; i++)
                {
                    if (!showSystemNameSpaces)
                    {
                        if (assemblies[i].FullName.ToLower().StartsWith("system."))
                        {
                            continue;
                        }
                    }
                    sb.Append("<tr>");
                    sb.Append("<td align=\"right\" width=\"30\" nowrap>");
                    sb.Append(i.ToString() + ".");
                    sb.Append("</td>");
                    sb.Append("<td align=\"left\">");
                    sb.Append(assemblies[i].FullName);
                    sb.Append("</td>");
                    sb.Append("</tr>");
                }

                sb.Append("</table>");
                

            }
            catch (Exception) { throw; }
            return sb.ToString();
        }
        #endregion

    }
}
