using System;
using System.Collections.Generic;
using System.Text;

namespace SourceCodeManager
{
    public class CodeContainer
    {
        #region Local Variables
        private string sourceCode = "";
        private string uniqueKey = "";
        private string nameSpace = "";
        private string className = "";
        private System.Reflection.Assembly compiledAssembly = null;
        #endregion

        #region Unique Key
        public string UniqueKey
        {
            get
            {
                return uniqueKey;
            }
            set
            {
                if (value != uniqueKey)
                {
                    uniqueKey = value.Trim();
                }
            }
        }
        #endregion

        #region Source Code
        public string SourceCode
        {
            get
            {
                return sourceCode;
            }
            set
            {
                if (value != sourceCode)
                {
                    sourceCode = value.Trim();
                }
            }
        }
        #endregion

        #region Name Space
        public string NameSpace
        {
            get
            {
                return nameSpace;
            }
            set
            {
                if (value != nameSpace)
                {
                    nameSpace = value.Trim();
                }
            }
        }
        #endregion

        #region Class Name
        public string ClassName
        {
            get
            {
                return className;
            }
            set
            {
                if (value != className)
                {
                    className = value.Trim();
                }
            }
        }
        #endregion

        #region Compiled Assembly
        public System.Reflection.Assembly CompiledAssembly
        {
            get
            {
                return compiledAssembly;
            }
            set
            {
 
                compiledAssembly = value;
            }
        }
        #endregion

    }
}
