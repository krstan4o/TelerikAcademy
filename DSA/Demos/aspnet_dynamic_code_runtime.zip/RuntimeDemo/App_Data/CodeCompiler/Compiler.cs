using System;
using System.Data;
using System.Configuration;
using System.CodeDom.Compiler;
using Microsoft.CSharp;
using System.Text;
using System.Reflection;
using System.Diagnostics;
using System.Security.Policy;
using System.IO;
using System.Web;

namespace SourceCodeManager
{
 /// <summary>
 /// Summary description for Compiler
 /// </summary>
 public class Compiler
 {
    private CompilerErrorCollection compilerErrors = null;
    
    #region Constructor
    public Compiler()
    {
        compilerErrors = new CompilerErrorCollection();
    }
    #endregion

    #region Errors
    public CompilerErrorCollection Errors
    {
        get { return compilerErrors; }
    }
    #endregion

    #region Compile
     public System.Reflection.Assembly Compile(string sourceCode)
     {
         CSharpCodeProvider provider = new CSharpCodeProvider();
         CompilerParameters parameters = new CompilerParameters();
         CompilerResults results = null;
         StringBuilder sb = new StringBuilder();

         try
         {

             parameters.OutputAssembly = "SourceCodeManager";    
             parameters.ReferencedAssemblies.Add("system.dll");
             parameters.ReferencedAssemblies.Add("system.xml.dll");
             parameters.ReferencedAssemblies.Add("system.data.dll");
             parameters.ReferencedAssemblies.Add("system.web.dll");
             parameters.CompilerOptions = "/t:library";
             parameters.GenerateInMemory = true;
             parameters.GenerateExecutable = false;
             parameters.IncludeDebugInformation = false;

             sb.Append("using System;" + "\n");
             sb.Append("using System.Collections.Generic;" + "\n\n");
             sb.Append("using System.Xml;" + "\n");
             sb.Append("using System.Data;" + "\n\n");
             sb.Append("using System.Web;" + "\n\n");

             sb.Append(sourceCode);
           
             results = provider.CompileAssemblyFromSource(parameters,
                                                          sb.ToString());

             if (results.Errors.Count != 0)
             {
                 compilerErrors = results.Errors;
                 throw new Exception("Code compilation errors occurred.");
             }
             else
             {
                 return results.CompiledAssembly; 
             }

         }
         catch (Exception) { throw; }
        

     }
     #endregion

  }

}
 