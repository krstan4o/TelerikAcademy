using System;
using System.Data;
using System.Collections.Generic; 
using System.Configuration;
using System.Diagnostics; 
using System.Web;
using System.Web.Security;
using System.Text;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Threading;

public partial class _Default : System.Web.UI.Page 
{
    protected void Page_Load(object sender, EventArgs e)
    {
       
        try
        {

            if (!Page.IsPostBack)
            {

               // Let's write some sample code for use in this demo.
               

               StringBuilder sb = new StringBuilder();

               sb.Append("namespace MyNameSpace" + "\n");
               sb.Append("{ " + "\n");
               sb.Append("   public class MyClassName" + "\n");
               sb.Append("   { " + "\n");
               sb.Append("      public bool Validate(List<int> parameter1," + "\n");
               sb.Append("                           List<int> parameter2) " + "\n");
               sb.Append("      { " + "\n");
               sb.Append("        int i = 5;" + "\n");
               sb.Append("                          " + "\n");
               sb.Append("         try " + "\n");
               sb.Append("         { " + "\n");
               sb.Append("            if (i==1)" + "\n");
               sb.Append("            {" + "\n");
               sb.Append("              return true; " + "\n");
               sb.Append("            }" + "\n");
               sb.Append("            if (parameter1.Count==1)" + "\n");
               sb.Append("            {" + "\n");
               sb.Append("              return true; " + "\n");
               sb.Append("            }" + "\n");
               sb.Append("            return false; " + "\n");
               sb.Append("         } " + "\n");
               sb.Append("         catch (Exception) { throw; }" + "\n");
               sb.Append("         return false; " + "\n");
               sb.Append("      } " + "\n");
               sb.Append("  } " + "\n");
               sb.Append("}" + "\n\n");
  
               this.Label1.Text = ""; 
               this.TextBox1.Text = sb.ToString();

            }
          
        }
        catch (Exception err)
        {
           this.Label1.Text = err.Message;
        }
    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        SourceCodeManager.Runtime runtime = new SourceCodeManager.Runtime();
        SourceCodeManager.CodeContainer codeContainer = null;
        string methodName = "Validate";
        object[] parameters = null;

        try
        {

            // Simulate pulling code from disk or from database.

            codeContainer = new SourceCodeManager.CodeContainer();
            codeContainer.ClassName = "MyClassName";
            codeContainer.NameSpace = "MyNameSpace";
            codeContainer.UniqueKey = "robbe";
            codeContainer.SourceCode = this.TextBox1.Text;

            // Compare this code with that which is set in
            // our static List<CodeContainer> by the UniqueKey.
            // If not found, compile and add.
            // If found but source code is different, delete, compile, and add.
            // If found and source code is the same, grab reference to
            // previously compiled assembly.

            SourceCodeManager.Registration.Update(codeContainer);

            // Let's create some sample parameters to pass into
            // our dynamically compiled class/method.

            parameters = new object[2];

            List<int> parameter1 = new List<int>();

            parameter1.Add(5);
            parameter1.Add(10);

            List<int> parameter2 = new List<int>();

            parameter2.Add(50);
            parameter2.Add(100);

            parameters[0] = parameter1;
            parameters[1] = parameter2;

            // Execute the desired method and pass in our parameters.
            // Our Execute method will always return an object.  So,
            // we need to know its actual desired return type ahead
            // of time if we want to convert it to the property Type.

            bool returnValue = (bool)runtime.Execute(codeContainer,
                                                     methodName,
                                                     parameters);

            this.Label1.Text =  "Method result: " + returnValue.ToString();
                                             

        }
        catch (Exception err)
        {
            this.Label1.Text = err.Message;
        }
        finally { runtime = null; }
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        try
        {
             

        }
        catch (Exception err)
        {
            this.Label1.Text = err.Message;
        }
    }
}
