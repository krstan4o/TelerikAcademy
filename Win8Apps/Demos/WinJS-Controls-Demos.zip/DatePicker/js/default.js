﻿(function () {
    "use strict";

    var app = WinJS.Application;
    var activation = Windows.ApplicationModel.Activation;
    WinJS.strictProcessing();

    app.onactivated = function (args) {
        if (args.detail.kind === activation.ActivationKind.launch) {
            if (args.detail.previousExecutionState !== activation.ApplicationExecutionState.terminated) {
            } else {
            }
            args.setPromise(WinJS.UI.processAll());

            var datePickerHostElement = document.getElementById("date-picker-host-id");
            var datePickerElement = new WinJS.UI.DatePicker(datePickerHostElement);
            datePickerElement.addEventListener("change", datePickerElementChange);
        }
    };

    app.oncheckpoint = function (args) {
    };

    var datePickerElementChange = function (eventInfo) {
        var outputElement = document.getElementById("output-id");
        var datePickerElement = document.getElementById("date-picker-host-id").winControl;
        outputElement.innerText = "code-generated DatePicker changed to:\r\n" + datePickerElement.current;
    }

    app.start();
})();
