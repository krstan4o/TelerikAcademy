﻿// For an introduction to the Blank template, see the following documentation:
// http://go.microsoft.com/fwlink/?LinkId=232509
(function () {
    "use strict";

    var app = WinJS.Application;
    var activation = Windows.ApplicationModel.Activation;
    WinJS.strictProcessing();

    app.onactivated = function (args) {
        if (args.detail.kind === activation.ActivationKind.launch) {
            args.setPromise(WinJS.UI.processAll());
        }

        var mainContentElement = document.getElementById("main-content-id");
        var showFlyoutElement = document.getElementById("show-flyout-id");
        showFlyoutElement.addEventListener("click", showFlyoutClicked);


    };

    var showFlyoutClicked = function () {
        var showFlyoutElement = document.getElementById("show-flyout-id");
        var flyoutElement = document.getElementById("flyout-id").winControl;
        flyoutElement.show(showFlyoutElement);
    }

    app.start();
})();
