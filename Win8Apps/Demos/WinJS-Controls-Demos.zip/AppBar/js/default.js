﻿// For an introduction to the Blank template, see the following documentation:
// http://go.microsoft.com/fwlink/?LinkId=232509
(function () {
    "use strict";

    var app = WinJS.Application;
    var activation = Windows.ApplicationModel.Activation;
    WinJS.strictProcessing();

    app.onactivated = function (args) {
        if (args.detail.kind === activation.ActivationKind.launch) {

            args.setPromise(WinJS.UI.processAll());

            var showAppBarElement = document.getElementById("show-appbar-button-id");
            showAppBarElement.addEventListener("click", showAppBarClicked);
        }
    };

    var showAppBarClicked = function () {
        var appBar = document.getElementById("appbar-id").winControl;
        appBar.show();
    }

    app.start();
})();
