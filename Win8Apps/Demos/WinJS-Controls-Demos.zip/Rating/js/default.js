﻿// For an introduction to the Blank template, see the following documentation:
// http://go.microsoft.com/fwlink/?LinkId=232509
(function () {
    "use strict";

    var app = WinJS.Application;
    var activation = Windows.ApplicationModel.Activation;
    WinJS.strictProcessing();

    app.onactivated = function (args) {
        if (args.detail.kind === activation.ActivationKind.launch) {
            args.setPromise(WinJS.UI.processAll());

            var ratingElementHost = document.getElementById("rating-id");
            var ratingElement = new WinJS.UI.Rating(ratingElementHost);
            ratingElement.maxRating = 10;
            ratingElement.addEventListener("change", ratingElementChanged);
        }
    };

    var ratingElementChanged = function () {
        var ratingElement = document.getElementById("rating-id").winControl;
        var outputElement = document.getElementById("output-id");
        outputElement.innerText = "Rating changed to: " + ratingElement.userRating;
    }

    app.start();
})();
