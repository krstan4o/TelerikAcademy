﻿// For an introduction to the Blank template, see the following documentation:
// http://go.microsoft.com/fwlink/?LinkId=232509
(function () {
    "use strict";

    var app = WinJS.Application;
    var activation = Windows.ApplicationModel.Activation;
    WinJS.strictProcessing();

    app.onactivated = function (args) {
        if (args.detail.kind === activation.ActivationKind.launch) {
            args.setPromise(WinJS.UI.processAll());

            var openElement = document.getElementById("open-button-id");
            openElement.addEventListener("click", openElementClicked);
        }
    };

    var openElementClicked = function () {
        var menu = document.getElementById("menu-id").winControl;
        menu.show();
    }

    app.start();
})();
