﻿(function () {
    var computer = {
        name: "",
        imageUrl: "",
        price: 0,
        processor: {
            modelName: "",
            frequencyGHz: 0
        }
    }

    var getComputer = function (name, price, imageUrl, processorName, processorGHz) {
        return new ObservableComputer({
            name: name,
            imageUrl: imageUrl,
            price: price,
            processor: {
                modelName: processorName,
                frequencyGHz: processorGHz
            }
        });
    }

    var ObservableComputer = WinJS.Binding.define(computer);
    var firstComputerObservable = getComputer("Dell Studio 1535", 2000, "/images/studio-1535.png", "Core i5", 2.0);
    var secondComputerObservable = getComputer("HP 650", 1500, "/images/hp-650.jpg", "Intel 1000M", 1.8)

    var computersList = new WinJS.Binding.List([firstComputerObservable, secondComputerObservable]);

    var dataArray = [
  { title: "Basic banana", text: "Low-fat frozen yogurt", picture: "images/60banana.png" },
  { title: "Banana blast", text: "Ice cream", picture: "images/60banana.png" },
  { title: "Brilliant banana", text: "Frozen custard", picture: "images/60banana.png" },
  { title: "Orange surprise", text: "Sherbet", picture: "images/60orange.png" },
  { title: "Original orange", text: "Sherbet", picture: "images/60orange.png" },
  { title: "Vanilla", text: "Ice cream", picture: "images/60vanilla.png" },
  { title: "Very vanilla", text: "Frozen custard", picture: "images/60vanilla.png" },
  { title: "Marvelous mint", text: "Gelato", picture: "images/60mint.png" },
  { title: "Succulent strawberry", text: "Sorbet", picture: "images/60strawberry.png" }
    ];

    var foodList = new WinJS.Binding.List(dataArray);

    WinJS.Namespace.define("Data", {
        computers: computersList,
        food: foodList
    });
})()