﻿/// <reference path="//Microsoft.WinJS.1.0/js/base.js" />


(function () {
    var showListViewSelection = function (event) {
        console.log("SELECTION CHANGED")

        var triggeringListView = this.winControl;

        triggeringListView.selection.getItems().then(function (items) {
            console.log("Selected Items: ");
            items.forEach(function (item) {
                console.log(JSON.stringify(item.data));
            });
        });

        itemIndices = triggeringListView.selection.getIndices();
        console.log("Selected Item Indices: ");
        console.log(itemIndices.join(", "));
    };

    var showListViewInvokedItem = function (event) {
        console.log("ITEM INVOKED");

        var triggeringListView = event.srcElement.winControl;

        event.detail.itemPromise.then(function (item) {
            console.log("Invoked Item: ");
            console.log(JSON.stringify(item.data));
        });

        console.log("Invoked Item Index");
        console.log(event.detail.itemIndex);
    }

    WinJS.Utilities.markSupportedForProcessing(showListViewSelection);
    WinJS.Utilities.markSupportedForProcessing(showListViewInvokedItem);

    WinJS.Namespace.define("Commands", {
        showListViewSelection: showListViewSelection,
        showListViewInvokedItem: showListViewInvokedItem
    });
})()