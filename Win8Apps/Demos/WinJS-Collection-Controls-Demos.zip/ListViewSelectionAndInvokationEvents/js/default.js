﻿// For an introduction to the Blank template, see the following documentation:
// http://go.microsoft.com/fwlink/?LinkId=232509
(function () {
    "use strict";

    WinJS.Binding.optimizeBindingReferences = true;

    var app = WinJS.Application;
    var activation = Windows.ApplicationModel.Activation;

    app.onactivated = function (args) {
        console.log();
        window.console = new DomLogger(document.getElementById("output"));

        args.setPromise(WinJS.UI.processAll());

    };

    app.start();
})();
