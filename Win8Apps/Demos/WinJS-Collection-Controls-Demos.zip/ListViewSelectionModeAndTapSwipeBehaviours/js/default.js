﻿// For an introduction to the Blank template, see the following documentation:
// http://go.microsoft.com/fwlink/?LinkId=232509
(function () {
    "use strict";

    WinJS.Binding.optimizeBindingReferences = true;

    var app = WinJS.Application;
    var activation = Windows.ApplicationModel.Activation;

    app.onactivated = function (args) {
        console.log();

        var output = document.getElementById("output");
        window.console = new DomLogger(output);

        args.setPromise(WinJS.UI.processAll().then(function () {

            var listview = document.getElementById("listview").winControl;

            var selectionModeSwitch = document.getElementById("selection-mode-switch").winControl;
            var swipeBehaviorSwitch = document.getElementById("swipe-behavior-switch").winControl;
            var tapBehaviorRadios = document.getElementById("tap-behavior-radios");

            var invokeOnlyRadio = document.getElementById("tap-invoke-only");
            var directSelectRadio = document.getElementById("tap-direct-select");
            var toggleSelectRadio = document.getElementById("tap-toggle-select");
            var noneRadio = document.getElementById("tap-none");

            tapBehaviorRadios.addEventListener("click", function () {
                for (var i = 0; i < this.childNodes.length; i++) {
                    if (this.childNodes[i].checked) {
                        listview.tapBehavior = this.childNodes[i].value;
                    }
                }
            })

            selectionModeSwitch.addEventListener("change", function () {
                if (this.winControl.checked) {
                    listview.selectionMode = WinJS.UI.SelectionMode.multi;
                }
                else {
                    listview.selectionMode = WinJS.UI.SelectionMode.single;
                }
            })
            
            swipeBehaviorSwitch.addEventListener("change", function () {
                if (this.winControl.checked) {
                    listview.swipeBehavior = WinJS.UI.SwipeBehavior.select;
                }
                else {
                    listview.swipeBehavior = WinJS.UI.SwipeBehavior.none;
                }
            });

            var clearOutput = document.getElementById("clear-output");
            clearOutput.addEventListener("click", function () {
                console.log("", true);
            });
        }));

    };

    app.start();
})();
