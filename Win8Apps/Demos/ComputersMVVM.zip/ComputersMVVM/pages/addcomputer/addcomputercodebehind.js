﻿(function () {
    var submitComputer = function () {
        var computerNameInput = document.getElementById("computer-name-input");
        var computerName = computerNameInput.value;

        ViewModels.addComputer(computerName, "unknown", "unknown", "unknown", "unknown");
    }

    WinJS.Utilities.markSupportedForProcessing(submitComputer);

    WinJS.Namespace.define("AddComputerCodeBehind", {
        submitComputer: submitComputer
    });
})()