﻿(function () {

    var goToComputerDetailsPage = function (invokeEvent) {
        WinJS.Navigation.navigate("/pages/computerdetails/computerdetails.html", {
            indexInComputersList: invokeEvent.detail.itemIndex
        });
    }

    WinJS.Utilities.markSupportedForProcessing(goToComputerDetailsPage);

    WinJS.Namespace.define("HomeCodeBehind", {
        callLoadComputers: function () {
            ViewModels.loadComputers();
        },

        goToComputerDetailsPage: goToComputerDetailsPage
    })
})();