﻿(function () {
    var ComputerModel = WinJS.Class.define(function (model, manufacturer, processorModel, processorFrequencyGHz, memoryMB) {
        this.model = model;
        this.manufacturer = manufacturer;
        this.processor = {}; //very important line, else the processor is added to the prototype and shared between all instances
        this.processor.model = processorModel;
        this.processor.frequencyGHz = processorFrequencyGHz,
        this.memoryMB = memoryMB;
    }, {
        model: "",
        manufacturer: "",
        processor: {
            model: "",
            frequencyGHz: 0
        },
        memoryMB: 0
    })

    WinJS.Namespace.define("Models", {
        ComputerModel: ComputerModel
    })
})()