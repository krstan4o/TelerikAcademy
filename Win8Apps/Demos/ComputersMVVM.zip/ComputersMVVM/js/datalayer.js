﻿(function () {

    var computers = [
            new Models.ComputerModel("Studio", "Dell", "Intel Core i7", 2.0, 8000),
            new Models.ComputerModel("HP 650", "HP", "Intel Core i5", 2.0, 4000),
            new Models.ComputerModel("Aspire", "Acer", "Intel Core i3", 2.0, 4096),
            new Models.ComputerModel("Surface", "Microsoft", "ARM", 1.0, 1024),
    ]

    var getComputers = function () {
        return computers;
    }

    var addComputer = function(computerModel){
        computers.push(computerModel);
    }

    WinJS.Namespace.define("Data", {
        getComputers: getComputers,
        addComputer: addComputer
    });
})()