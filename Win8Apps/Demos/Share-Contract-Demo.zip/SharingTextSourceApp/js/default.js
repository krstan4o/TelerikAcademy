﻿// For an introduction to the Blank template, see the following documentation:
// http://go.microsoft.com/fwlink/?LinkId=232509
(function () {
    "use strict";

    WinJS.Binding.optimizeBindingReferences = true;

    var app = WinJS.Application;
    var activation = Windows.ApplicationModel.Activation;
    var dataTransferManager = Windows.ApplicationModel.DataTransfer.DataTransferManager.getForCurrentView();

    app.onactivated = function (args) {

        var shareTextHandler = function (event) {
            var dataRequest = event.request;

            dataRequest.data.properties.title =
                "Duck Enterprises Default Message";
            dataRequest.data.properties.description =
                "A default mail message from Duck Enterprises";
            dataRequest.data.setText(
                "Quack, quack-a-quack quaaaaaack\r\nDuck Enterprises TM, Address: Anylakerivertown, E-mail: quack@duck.com"
                );
        }

       dataTransferManager.addEventListener("datarequested", shareTextHandler)
    };

    app.start();
})();
