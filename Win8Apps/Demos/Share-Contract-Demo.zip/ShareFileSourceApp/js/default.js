﻿// For an introduction to the Blank template, see the following documentation:
// http://go.microsoft.com/fwlink/?LinkId=232509
(function () {
    "use strict";

    WinJS.Binding.optimizeBindingReferences = true;

    var app = WinJS.Application;
    var activation = Windows.ApplicationModel.Activation;
    var dataTransferManager = Windows.ApplicationModel.DataTransfer.DataTransferManager.getForCurrentView();

    app.onactivated = function (args) {
        var shareFileHandler = function (event) {
            var dataRequest = event.request;

            dataRequest.data.properties.title = "Posted JSON";
            dataRequest.data.properties.description = "JSON text file from http://posted.apphb.com/api/posts";
            
            dataRequest.data.properties.fileTypes.replaceAll([".txt"]);
            
            var deferral = dataRequest.getDeferral();

            WinJS.xhr({ url: "http://posted.apphb.com/api/posts" }).then(function (request) {
                var text = request.responseText;

                var localFolder = Windows.Storage.ApplicationData.current.localFolder;
                localFolder.createFileAsync("postedJSON.txt", Windows.Storage.CreationCollisionOption.replaceExisting).done(function (file) {
                    Windows.Storage.FileIO.writeTextAsync(file, text).done(function () {
                        dataRequest.data.setStorageItems([file]);
                        deferral.complete();
                    });
                });
            }, function (error) {
                deferral.complete();
            }).done(null, function (err) {
                deferral.complete();
            });
        }

        dataTransferManager.addEventListener("datarequested", shareFileHandler)
    };

    app.start();
})();
