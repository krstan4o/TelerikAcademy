﻿// For an introduction to the Blank template, see the following documentation:
// http://go.microsoft.com/fwlink/?LinkId=232509
(function () {
    "use strict";

    WinJS.Binding.optimizeBindingReferences = true;

    var app = WinJS.Application;
    var activation = Windows.ApplicationModel.Activation;
    var dataTransferManager = Windows.ApplicationModel.DataTransfer.DataTransferManager.getForCurrentView();

    app.onactivated = function (args) {

        var shareImageHandler = function (event) {
            var dataRequest = event.request;

            dataRequest.data.properties.title = "Duck Enterprises Logo";
            dataRequest.data.properties.description = "The Logo of Duck Enterprises";
            dataRequest.data.properties.thumbnail =
                Windows.Storage.Streams.RandomAccessStreamReference.createFromUri(
                new Windows.Foundation.Uri("ms-appx:///images/duck-logo-thumbnail.bmp")
                );

            var bitmapStream =
                Windows.Storage.Streams.RandomAccessStreamReference.createFromUri(
                new Windows.Foundation.Uri("ms-appx:///images/duck-logo.bmp")
                );

            dataRequest.data.setBitmap(bitmapStream);
        }

        dataTransferManager.addEventListener("datarequested", shareImageHandler)
    };

    app.start();
})();
