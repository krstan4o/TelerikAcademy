﻿// For an introduction to the Blank template, see the following documentation:
// http://go.microsoft.com/fwlink/?LinkId=232509
(function () {
    "use strict";

    var app = WinJS.Application;

    app.onactivated = function () {
        var textInput = document.getElementById("text-input");
        var saveText = document.getElementById("save-text");

        saveText.addEventListener("click", function () {
            var textToSave = textInput.value;

            var savePicker = new Windows.Storage.Pickers.FileSavePicker();
            savePicker.defaultFileExtension = ".txt"
            savePicker.fileTypeChoices.insert("Plain Text", [".txt"])
            savePicker.fileTypeChoices.insert("JSON", [".json"]);
            savePicker.suggestedFileName = "New Text Document";

            savePicker.pickSaveFileAsync().then(function (file) {
                var textToWrite = textInput.value;
                if (file.fileType == ".json") {
                    Windows.Storage.FileIO.writeTextAsync(file, "{\"text\":\"" + textToWrite + "\"}");
                }
                else {
                    Windows.Storage.FileIO.writeTextAsync(file, textToWrite);
                }
            });
        });
        
    };

    app.start();
})();
