﻿// For an introduction to the Blank template, see the following documentation:
// http://go.microsoft.com/fwlink/?LinkId=232509
(function () {
    var app = WinJS.Application;

    app.onactivated = function (args) {

        var loadedSongsList = document.getElementById("loaded-songs");
        var player = document.getElementById("player");

        loadedSongsList.addEventListener("click", function (event) {
            var songEntry = event.target;

            if (songEntry.tagName.toLowerCase() == "strong") {
                songEntry = songEntry.parentElement;
            }

            player.src = songEntry.getAttribute("data-song-url");
            player.play();
        });

        var addSongListEntry = function (songName, songAlbum, songUrl) {
            var songEntry = document.createElement("li");
            songEntry.setAttribute("data-song-url", songUrl);
            songEntry.innerHTML = "<strong>" + songName + "</strong>" + " - " + songAlbum;
            loadedSongsList.appendChild(songEntry);
        }

        var addSong = function (storageFile) {
            var fileUrl = URL.createObjectURL(storageFile);

            storageFile.properties.getMusicPropertiesAsync().then(function (properties) {
                properties.album;
                properties.title

                addSongListEntry(properties.title, properties.album, fileUrl);
            });
        }

        WinJS.Utilities.id("pick-file-button").listen("click", function () {
            var openPicker = Windows.Storage.Pickers.FileOpenPicker();

            openPicker.fileTypeFilter.append("*");
            openPicker.pickSingleFileAsync().then(addSong);
        });

        WinJS.Utilities.id("pick-multiple-files-button").listen("click", function () {
            var openPicker = Windows.Storage.Pickers.FileOpenPicker();

            openPicker.fileTypeFilter.append("*");
            openPicker.pickMultipleFilesAsync().then(function (files) {
                files.forEach(addSong);
            });
        });
    };

    app.start();
})();
