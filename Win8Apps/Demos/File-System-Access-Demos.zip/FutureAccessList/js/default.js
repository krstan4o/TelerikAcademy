﻿// For an introduction to the Blank template, see the following documentation:
// http://go.microsoft.com/fwlink/?LinkId=232509
(function () {
    "use strict";

    var app = WinJS.Application;
    var appData = Windows.Storage.ApplicationData.current;
    var storagePermissions = Windows.Storage.AccessCache.StorageApplicationPermissions;

    var permissionTokens = appData.localSettings.values["permissionTokens"];
    if (permissionTokens) {
        permissionTokens = JSON.parse(permissionTokens);
    }
    else {
        permissionTokens = [];
        appData.localSettings.values["permissionTokens"] = JSON.stringify(permissionTokens);
    }

    app.onactivated = function () {
        var openFile = document.getElementById("open-file");
        var accessibleFilesList = document.getElementById("accessible-files");

        var printFutureAccessList = function () {
            var entry;

            accessibleFilesList.innerHTML = "";

            for (var i = 0; i < permissionTokens.length; i++) {
                var currToken = permissionTokens[i];
                storagePermissions.futureAccessList.getFileAsync(currToken).then(function (currFile) {
                    var listEntry = document.createElement("li");
                    listEntry.innerHTML += "<strong>" + currFile.name + "</strong> " + currFile.path;
                    accessibleFilesList.appendChild(listEntry);
                });
            }
        }

        openFile.addEventListener("click", function () {
            var fileOpenPicker = new Windows.Storage.Pickers.FileOpenPicker();
            fileOpenPicker.fileTypeFilter.append("*");
            fileOpenPicker.pickSingleFileAsync().then(function (file) {
                if (file) {
                    var token = permissionTokens.length + file.name;
                    storagePermissions.futureAccessList.addOrReplace(token, file);

                    permissionTokens.push(token);
                    appData.localSettings.values["permissionTokens"] = JSON.stringify(permissionTokens);
                }

                printFutureAccessList();
            });
        });

        printFutureAccessList();
    };

    app.start();
})();
