﻿// For an introduction to the Blank template, see the following documentation:
// http://go.microsoft.com/fwlink/?LinkId=232509
(function () {
    var app = WinJS.Application;

    app.onactivated = function (args) {

        var player = document.getElementById("player");
        var outputElement = document.getElementById("output");

        WinJS.Utilities.id("pick-button").listen("click", function () {
            var openPicker = Windows.Storage.Pickers.FolderPicker();

            openPicker.fileTypeFilter.append("*");
            openPicker.pickSingleFolderAsync().then(function (folder) {
                outputElement.innerHTML += "<h2>" + folder.name + "</h2>";

                folder.getFilesAsync().then(function (files) {
                    var filesHtmlListString = "<ul>";

                    for (var i = 0; i < files.length; i++) {
                        filesHtmlListString += "<li>" + files[i].name + "</li>"
                    }

                    filesHtmlListString += "</ul>";

                    outputElement.innerHTML += filesHtmlListString;
                }).done();
            });
        });
    };

    app.start();
})();
