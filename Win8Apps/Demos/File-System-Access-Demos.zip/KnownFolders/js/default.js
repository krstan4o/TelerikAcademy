﻿// For an introduction to the Blank template, see the following documentation:
// http://go.microsoft.com/fwlink/?LinkId=232509
(function () {
    "use strict";

    WinJS.Binding.optimizeBindingReferences = true;

    var app = WinJS.Application;

    app.onactivated = function (args) {

        Windows.Storage.KnownFolders.documentsLibrary.createFileAsync("known-folders-demo-file.txt", Windows.Storage.CreationCollisionOption.replaceExisting);

        var outputElement = document.getElementById("output");

        Windows.Storage.KnownFolders.documentsLibrary.getFilesAsync().then(function (files) {
            outputElement.innerHTML += "<h2>Documents Library:</h2><ul>";
            for (var i = 0; i < files.length; i++) {
                outputElement.innerHTML += "<li>" + files[i].name + "</li>";
            }
            outputElement.innerHTML += "</ul>";
        });
    };

    app.start();
})();
