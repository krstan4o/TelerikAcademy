﻿// For an introduction to the Blank template, see the following documentation:
// http://go.microsoft.com/fwlink/?LinkId=232509
(function () {
    "use strict";

    var app = WinJS.Application;

    app.onactivated = function () {
        var file;
        var filePicker = new Windows.Storage.Pickers.FileOpenPicker();
        filePicker.fileTypeFilter.append(".txt");
        filePicker.commitButtonText = "Pick .txt file for demo";
        filePicker.pickSingleFileAsync().done(function (pickedFile) {
            file = pickedFile;
        });

        var textInput = document.getElementById("text-input");
        var writeButton = document.getElementById("write-text");
        var readButton = document.getElementById("read-contents");
        var fileContentsElement = document.getElementById("file-contents");
        var writeMessages = document.getElementById("write-messages");
        var overwriteSetting = document.getElementById("overwrite-setting");

        writeButton.addEventListener("click", function () {
            var textToWrite = textInput.value;

            var writeSuccessMessage = function () {
                writeMessages.value += "Text successfully written to file\r\n";
            }

            var writeErrorMessage = function (error) {
                writeMessages.value += "Error writing to file:\r\n" + JSON.stringify(error);
            }

            file.openTransactedWriteAsync().then(function (transaction) {
                var writer = Windows.Storage.Streams.DataWriter(transaction.stream);
                writer.writeString(textToWrite);
                writer.storeAsync().done(function () {
                    transaction.commitAsync().done(function () {
                        transaction.close();
                    });
                });
            });
        });

        readButton.addEventListener("click", function () {
            Windows.Storage.FileIO.readTextAsync(file).done(function (text) {
                fileContentsElement.value = text;
            })
        });
    };

    app.start();
})();
