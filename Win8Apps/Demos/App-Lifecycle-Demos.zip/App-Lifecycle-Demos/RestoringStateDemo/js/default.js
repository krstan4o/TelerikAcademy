﻿(function () {
    "use strict";

    var app = WinJS.Application;
    var activation = Windows.ApplicationModel.Activation;
    WinJS.strictProcessing();

    app.onactivated = function (args) {
        if (args.detail.kind === activation.ActivationKind.launch) {
            if (args.detail.previousExecutionState !== activation.ApplicationExecutionState.terminated) {
                
            } else {
                var statusInputElementValue = WinJS.Application.sessionState["statusInputElementValue"];
                if (statusInputElementValue) {
                    var statusInputElement = document.getElementById("status-input-id");
                    statusInputElement.value = statusInputElementValue;
                }
            }
            args.setPromise(WinJS.UI.processAll());

            var updateStatusButton = document.getElementById("update-status-button-id");
            updateStatusButton.addEventListener("click", buttonUpdateStatusClicked);

            //statusInputElement.addEventListener("keyup", statusInputElementChange);

            initialize();
        }
    };

    app.oncheckpoint = function (args) {
        var statusInputElement = document.getElementById("status-input-id");
        WinJS.Application.sessionState["statusInputElementValue"] = statusInputElement.value.toString();
    };

    var setStatusText = function (statusText) {
        var statusContainerElement = document.getElementById("status-container-id");
        statusContainerElement.innerText = statusText;

        Windows.Storage.ApplicationData.current.localSettings.values["statusText"] = statusText;
    }

    var buttonUpdateStatusClicked = function () {
        var statusInputElement = document.getElementById("status-input-id");
        setStatusText(statusInputElement.value);
    }

    var statusInputElementChange = function() {
        //var statusInputElement = document.getElementById("status-input-id");
        //WinJS.Application.sessionState["statusInputElementValue"] = statusInputElement.value.toString();
    }

    var initialize = function () {
        var statusText = Windows.Storage.ApplicationData.current.localSettings.values["statusText"];
        if (statusText) {
            setStatusText(statusText);
        }
    }

    app.start();
})();
