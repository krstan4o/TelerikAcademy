﻿(function () {
    "use strict";

    var app = WinJS.Application;
    var activation = Windows.ApplicationModel.Activation;
    WinJS.strictProcessing();

    app.onactivated = function (args) {
        if (args.detail.kind === activation.ActivationKind.launch) {
            if (args.detail.previousExecutionState !== activation.ApplicationExecutionState.terminated) {
                
            } else {
                
            }
            args.setPromise(WinJS.UI.processAll());
        }
    };

    app.oncheckpoint = function (args) {
    };

    //Resuming the app
    //We just register for the "resuming" event and add a function that prints some text
    //
    //note: the resuming event is in somewhat a weird place right now (compared to oncheckpoint for example). Microsoft could change this in future
    Windows.UI.WebUI.WebUIApplication.addEventListener("resuming", function () {
        var contentElement = document.getElementById("content-element-id");
        contentElement.innerText = "Hey, you resumed me!"
    });    

    app.start();
})();
