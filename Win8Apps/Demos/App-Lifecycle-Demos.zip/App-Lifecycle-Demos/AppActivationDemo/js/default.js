﻿(function () {
    "use strict";

    var app = WinJS.Application;
    var activation = Windows.ApplicationModel.Activation;
    WinJS.strictProcessing();

    app.onactivated = function (args) {
        if (args.detail.kind === activation.ActivationKind.launch) {
            if (args.detail.previousExecutionState !== activation.ApplicationExecutionState.terminated) {
                
                //App has never run before or has been shutdown by user
                var contentElement = document.getElementById("content-element-id");
                contentElement.innerText = "I am starting fresh";

            } else {

                //App has been suspended and then terminated. If you have saved the previous state, this is a good time to restore it
                var contentElement = document.getElementById("content-element-id");
                contentElement.innerText = "I am starting after I have been suspended and terminated. \nI should restore my previous state (but I haven't saved it, so I'm showing this message)";
            }
            args.setPromise(WinJS.UI.processAll());
        }
    };

    app.oncheckpoint = function (args) {
    };

    app.start();
})();
