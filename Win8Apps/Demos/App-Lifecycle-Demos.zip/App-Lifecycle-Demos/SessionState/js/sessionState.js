﻿// For an introduction to the Blank template, see the following documentation:
// http://go.microsoft.com/fwlink/?LinkId=232509
(function () {
    "use strict";

    WinJS.Binding.optimizeBindingReferences = true;

    var app = WinJS.Application;
    var activation = Windows.ApplicationModel.Activation;

    app.onactivated = function (args) {
        if (args.detail.kind === activation.ActivationKind.launch) {

            args.setPromise(WinJS.UI.processAll());

            document.getElementById("textbox-id").oninput = function () {
                saveToSessionState('textbox-id');
            }

            if (app.sessionState["textbox-id"]) {
                document.getElementById("textbox-id").value = app.sessionState["textbox-id"];
            }
        }
    };

    function saveToSessionState(elementIdStr) {

        var element = document.getElementById(elementIdStr);
        app.sessionState[elementIdStr] = element.value;
    }


    app.start();
})();
