﻿/// <reference path="//Microsoft.WinJS.1.0/js/base.js" />
/// <reference path="bear.js" />
/// <reference path="domSpriteMixin.js" />

var SpriteBear = WinJS.Class.mix(Bear, DomSpriteMixin);