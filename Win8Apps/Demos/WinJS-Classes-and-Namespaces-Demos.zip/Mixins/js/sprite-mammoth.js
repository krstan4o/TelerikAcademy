﻿/// <reference path="animal.js" />
/// <reference path="mammoth.js" />
/// <reference path="domSpriteMixin.js" />

var SpriteMammoth = WinJS.Class.mix(Mammoth, DomSpriteMixin)