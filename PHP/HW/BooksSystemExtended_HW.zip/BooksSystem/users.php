<?php

include './includes/header.php';
if ($_GET && isset($_GET['id'])) {
    $userId = trim(mysqli_escape_string($connection, $_GET['id']));
    $query = "SELECT * FROM users u JOIN comments c ON(u.user_id=c.user_id) JOIN books b ON(b.book_id=c.book_id) WHERE u.user_id='" . $userId . "' ORDER BY c.date_created DESC";
    $q = mysqli_query($connection, $query);
    $row = mysqli_fetch_assoc($q);
    echo '<div id="wrapper">';
    echo '<h1>Comments by ' . $row['user_name'] . '</h1>';
    
    while ($row) {

       echo '<div class="comment-holder">';
        echo '<p>Book: <a href="book.php?bookId=' . $row['book_id'] . '">' . $row['book_title'] . '</a></p>';
        echo '<p>Date: ' . $row['date_created'] . '</p>';

        echo '<p>Comment: ' . $row['comment_text'] . '</p>';
echo '</div>';
        $row = mysqli_fetch_assoc($q);
    }
    echo '</div>';
} else {
    echo 'No user selected.';
}
include './includes/footer.php';
?>
