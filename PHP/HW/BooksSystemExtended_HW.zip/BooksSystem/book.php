<?php
session_start();
$pageTitle = 'Книга';
include './includes/header.php';
include './includes/helpers.php';
include './includes/constants.php';
if ($_POST) {
    $comment = trim(mysqli_real_escape_string($connection, $_POST['comment']));
    if(strlen($comment) < 2){
        $errors[] = 'Коментарът трябва да бъде поне 2 символа дълаг';
    }
    if (count($errors)) {
        foreach ($errors as $err) {
            echo $err.'<br>';        }
    }else{
        $userId = (int)trim(mysqli_real_escape_string($connection, $_SESSION['userIndex']));
        $bookId = trim(mysqli_real_escape_string($connection, $_POST['bookId']));
        $query = "INSERT INTO comments(date_created, user_id, book_id, comment_text) VALUES(NOW(),'".$userId."','".$bookId."','".$comment."')";
        $q=  mysqli_query($connection, $query);
        if (mysqli_error($connection)) {
            echo mysqli_error($connection);
        }else{
            echo 'Коментарът е въведен';
            header('Location: book.php?bookId='.$bookId);
        }
    }
}

if ($_GET && isset($_GET['bookId'])) {
    $bookId = trim($_GET['bookId']);
    $bookId = mysqli_real_escape_string($connection, $bookId);
    $query = "SELECT * FROM books b JOIN books_authors ba ON(b.book_id = ba.book_id) JOIN authors a ON(a.author_id = ba.author_id)
         WHERE b.book_id='" . $bookId . "'";

    $q = getBooks($connection, $query);
    
    $query = "SELECT c.comment_text, c.date_created, u.user_name, u.user_id FROM comments c JOIN users u ON(c.user_id=u.user_id)
        WHERE c.book_id='".$bookId."' ORDER BY c.date_created DESC";
    $q = mysqli_query($connection, $query);
     echo '<table class="comment-wrapper">';
    while ($row=mysqli_fetch_assoc($q)){
        echo '<tr class="info">';
        echo '<td><p>User: <a href="users.php?id='.$row['user_id'].'">'.$row['user_name'].'</a></p>';
        echo '<p>Date: '.$row['date_created'].'</p><td>';
       
        echo '<td class="comment-holder">'.$row['comment_text'].'</td>';
         echo '</tr>';
    }
     echo '</table><hr>';
     if (isLoggedIn()) {
         echo '<h4>Add new comment</h4>';
         echo '<form method="POST" action="book.php">';
         echo '<textarea name="comment"></textarea><br>';
           echo '<input type="hidden" value="'.$bookId.'" name="bookId" />';
         echo '<input type="submit" value="AddComment" />';
         
         echo '</form>';
     }
} else {
    echo 'Няма такава книга.';
}
include './includes/footer.php';
?>
