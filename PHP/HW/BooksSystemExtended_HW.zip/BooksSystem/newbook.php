<?php
$pageTitle = 'Нова книга';
include './includes/header.php';
    echo '<a href="index.php">Книги</a>';
    echo '<form method="POST">Име на книгата: <input type="text" name="book"/> <button type="submit">Добави</button><br>';
    echo '<select multiple="multiple" name="authors[]">';
      $query = mysqli_query($connection, 'SELECT * FROM authors');
        while ($rows = $query -> fetch_assoc())
                {
                    $authorName = $rows['author_name'];
                    $authorId = $rows['author_id'];
                    echo '<option value="'.$authorId.'">'.$authorName.'</option>';
                }
    echo '</select>';
    echo '</form>';
    if ($_POST) {
        include './includes/constants.php';
         if (isset($_POST['book']) && strlen($_POST['book']) >= 3) {
            $bookName = $_POST['book'];
         }
        else {
            $errors[] = 'Името на книгата трябва да бъде поне 3 символа.';
        }
        if (count($_POST['authors']) == 0) {
            $errors[] = 'Трябва да изберете поне един автор.';
        }
         if (count($errors) > 0) {
                foreach ($errors as $error) {
                     echo $error.'<br>';
                }
         }
        else {
            $bookName = mysqli_real_escape_string($connection,$bookName);
            mysqli_query($connection, "INSERT INTO books(book_title) VALUES('".$bookName."')");
            echo mysqli_error($connection);
            $bookId = mysqli_insert_id($connection);
            foreach ($_POST['authors'] as $authorId) {
                mysqli_query($connection, "INSERT INTO books_authors(book_id, author_id) VALUES('".$bookId."',"."'".$authorId."')");            
            }
        
            echo 'OK';
         }
    }
    include './includes/footer.php';