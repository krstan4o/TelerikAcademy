<?php
$pageTitle = 'Нов автор';
include './includes/header.php';
    echo '<a href="index.php">Книги</a>';
    echo '<form method="POST">Автор: <input type="text" name="author"/> <button type="submit">Добави</button></form>';
    
    echo '<table><tr><td>Автори</td></tr>';
        $query = mysqli_query($connection, 'SELECT * FROM authors');
        while ($rows = $query -> fetch_assoc())
                {
                    echo '<tr><td>';
                    echo '<a href="booksbyauthor.php?author='.$rows['author_name'].'">'.$rows['author_name'].'</a></td></tr>';
            
                }
    echo '</table>';
include './includes/footer.php';

if ($_POST) {
    include './includes/constants.php';
    if (isset($_POST['author']) && strlen($_POST['author']) >= 3) {
        $authorName = $_POST['author'];
        $q = mysqli_query($connection, "SELECT COUNT(*) FROM authors WHERE author_name='".$authorName."'");
        $rows = $q -> fetch_assoc();
        $count = (int)$rows['COUNT(*)'];
        if ($count > 0) {
            $errors[] = 'Съществува вече такъв автор в базата данни.';
        }  
    }
 else {
        $errors[] = 'Името на автора трябва да бъде поне 3 символа.';
    }
    if (count($errors) > 0) {
        foreach ($errors as $error) {
            echo $error.'<br>';
        }
    }
 else {
        $authorName = mysqli_real_escape_string($connection, $authorName);
        mysqli_query($connection, "INSERT INTO authors(author_name) VALUES('".$authorName."')");
        header('Location: newauthor.php');
    }
}
?>
