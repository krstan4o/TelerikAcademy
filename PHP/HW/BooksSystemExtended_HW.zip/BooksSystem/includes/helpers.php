<?php
function isLoggedIn(){
    if(isset($_SESSION['isLogged']) && $_SESSION['isLogged']){
       return true;
       return false;
    }
}
    function getBooks($connection, $query) {
         $q = mysqli_query($connection, $query);
     $result = array();
     //↑↓
     echo'<br><table border="2"><tr>';
     if (isset($_GET['author'])) {
         echo '<td>Книга <a href="booksbyauthor.php?author='.$_GET['author'].'&orderByTitle=ASC">↑</a>&nbsp&nbsp<a href="booksbyauthor.php?author='.$_GET['author'].'&orderByTitle=DESC">↓</a> </td>';
         echo '<td>Автори <a href="booksbyauthor.php?author='.$_GET['author'].'&orderByAuthor=ASC">↑</a>&nbsp&nbsp<a href="booksbyauthor.php?author='.$_GET['author'].'&orderByAuthor=DESC">↓</a> </td>';
     }
    else {
         echo '<td>Книга <a href="index.php?orderByTitle=ASC">↑</a>&nbsp&nbsp<a href="index.php?orderByTitle=DESC">↓</a> </td>';
         echo '<td>Автори <a href="index.php?orderByAuthor=ASC">↑</a>&nbsp&nbsp<a href="index.php?orderByAuthor=DESC">↓</a> </td>';
     }
     echo '</tr>';
     while ($row = $q -> fetch_assoc()){
         $result[$row['book_id']]['book_title'] = $row['book_title'];
         $result[$row['book_id']]['authors'][] = $row['author_name'];
     }
    // echo '<pre>'.print_r($result, true).'</pre>';

     foreach ($result as $key=>$res){
         echo '<tr>';
         echo '<td><a href="book.php?bookId='. $key .'">'.$res['book_title'].'</a></td>'; // todo get the book_id from $res
         
         echo '<td>';
         for ($i = 0; $i < count($res['authors']); $i++){
             if ($i < count($res['authors'])-1){
                 echo '<a href="booksbyauthor.php?author='.$res['authors'][$i].'">'.$res['authors'][$i].'</a>, ';
             }  else {
                 echo '<a href="booksbyauthor.php?author='.$res['authors'][$i].'">'.$res['authors'][$i].'</a>';
             }
         }
         echo '</td>';
        
         echo '</tr>';
     }
    echo '</table>';
        return count($result);
    }
?>
