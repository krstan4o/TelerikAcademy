<?php
function validateUsername($username, &$errors){
    $validUsernameChars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ_";
    if (strlen($username) < 3) {
        array_push($errors, 'Името трябва да бъде поне 3 символа.');
        return;
    }
    if (strlen($username) >= 26) {
        array_push($errors, 'Името трябва да бъде по-малко от 26 символа.');
        return;
    }
    
    for ($j = 0; $j < strlen($username); $j++){
        $isValidChar = false;
        for ($i = 0; $i < strlen($validUsernameChars); $i++){
            if($username[$j] == $validUsernameChars[$i]){
                $isValidChar = true;
                break;
            }
        }
        if($isValidChar == false){
            array_push($errors, 'Името трябва да съдържа само малки и голями латински букви, както и "_".');
            return;
        }
    }

}

function validatePassword($password, &$errors){
    if(strlen($password) <= 2){
       array_push($errors, 'Паролата трябва да бъде поне 3 символа.');
    }
    if(strlen($password) >= 21){
       array_push($errors, 'Паролата трябва да бъде по-малка от 20 символа.');
       return;
    }
}
?>
