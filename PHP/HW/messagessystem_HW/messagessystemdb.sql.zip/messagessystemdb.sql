-- phpMyAdmin SQL Dump
-- version 4.0.4.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Oct 06, 2013 at 09:40 PM
-- Server version: 5.5.32
-- PHP Version: 5.4.19

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `messagessystemdb`
--
CREATE DATABASE IF NOT EXISTS `messagessystemdb` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `messagessystemdb`;

-- --------------------------------------------------------

--
-- Table structure for table `groups`
--

CREATE TABLE IF NOT EXISTS `groups` (
  `group_id` int(11) NOT NULL AUTO_INCREMENT,
  `group_name` varchar(50) NOT NULL,
  PRIMARY KEY (`group_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `groups`
--

INSERT INTO `groups` (`group_id`, `group_name`) VALUES
(3, 'Коли'),
(2, 'Фитнес'),
(4, 'ИТ'),
(5, 'Друго');

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

CREATE TABLE IF NOT EXISTS `messages` (
  `message_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `message_text` text NOT NULL,
  `message_title` varchar(100) NOT NULL,
  `date_created` datetime NOT NULL,
  `group_id` int(11) NOT NULL,
  PRIMARY KEY (`message_id`),
  KEY `message_title` (`message_title`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=17 ;

--
-- Dumping data for table `messages`
--

INSERT INTO `messages` (`message_id`, `user_id`, `message_text`, `message_title`, `date_created`, `group_id`) VALUES
(10, 4, 'ddddddddd', 'sadasdas', '2013-10-06 02:31:11', 3),
(12, 9, 'капуууууууууууууууууууууууууууууут си ти мама му да ебаааа', 'Да ти еба майката', '2013-10-06 02:32:19', 2),
(14, 4, 'Мисля да си купя такова бмв дайте мнения.', 'BMW 325', '2013-10-06 12:00:42', 3),
(15, 4, 'Мечтата на всички', 'Audi S3', '2013-10-06 13:35:53', 3),
(16, 4, 'Нека всеки да сподели своята фитнес програма.....', 'Споелете програмата си!', '2013-10-06 13:37:00', 2);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_name` varchar(30) NOT NULL,
  `password` varchar(25) NOT NULL,
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `user_name` (`user_name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT='Containing users with password and messages' AUTO_INCREMENT=12 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `user_name`, `password`) VALUES
(4, 'krstancho', 'D@tas0l'),
(9, 'pencho', 'D@tas0l');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
