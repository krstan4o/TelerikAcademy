<!DOCTYPE html>
<html>
    <head>
        <title><?= $data['title']; ?></title>

<meta charset="UTF-8">
</head>
<body>
<?php
            include $data['content'];
            ?>
</body>
</html>