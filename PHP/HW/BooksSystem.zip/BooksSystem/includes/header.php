<!DOCTYPE HTML>
<html>
    <head>
        <title> <?php echo $pageTitle; ?> </title>
        <meta charset="UTF-8">
        <link rel="stylesheet" type="text/css" href="css/main.css">
    </head>
    <body>
        <?php 
            $connection = mysqli_connect('localhost', 'krstan4o', 'D@tas0l', 'books');
            mysqli_query($connection, 'SET NAMES utf8');
        ?>