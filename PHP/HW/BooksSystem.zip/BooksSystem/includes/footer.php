<?php
    echo '</body>';
    echo '</html>';
?>
