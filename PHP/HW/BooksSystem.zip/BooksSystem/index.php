<?php
    $pageTitle = 'Книги';
    include './includes/header.php';
    echo '<a href="newbook.php">Нова книга</a>&nbsp&nbsp';
    echo '<a href="newauthor.php"> Нов автор</a>';
    echo '<form method="GET"><input type="text" name="search"/><button type="submit">Търси книга</button></form>';
    $query = "SELECT * FROM books b JOIN books_authors ba ON(b.book_id = ba.book_id) JOIN authors a ON(a.author_id = ba.author_id)";
    include './includes/helpers.php';
    if ($_GET) {
        if (isset($_GET['orderByAuthor'])) {
              $orderByAuthor = mysqli_real_escape_string($connection, $_GET['orderByAuthor']);
              $query = $query . ' ORDER BY a.author_name '.$orderByAuthor;
              getBooks($connection, $query);
        }else if (isset($_GET['orderByTitle'])) {
              $orderByTitle = mysqli_real_escape_string($connection, $_GET['orderByTitle']);
              $query = $query . ' ORDER BY b.book_title '.$orderByTitle;
              getBooks($connection, $query);
        }else if(isset($_GET['search'])){
              $searchWord = mysqli_real_escape_string($connection, $_GET['search']);
              $query = $query . "WHERE b.book_title LIKE '%".$searchWord."%'";
              getBooks($connection, $query);
        }
    }else{
        getBooks($connection, $query);
    }
    include './includes/footer.php';
?>
