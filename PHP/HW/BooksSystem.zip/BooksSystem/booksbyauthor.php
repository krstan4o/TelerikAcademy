<?php
    if ($_GET) {
        if (isset($_GET['author'])) {
             $pageTitle = 'Книги от '.$_GET['author'];
             include './includes/header.php';
             echo '<a href="index.php">Книги</a>';
             $authorName = mysqli_real_escape_string($connection, $_GET['author']);
             $query = "SELECT *
FROM books b
JOIN books_authors ba ON ( ba.book_id = b.book_id )
JOIN authors a ON ( ba.author_id = a.author_id )
WHERE b.book_id
IN (

SELECT b.book_id
FROM books b
JOIN books_authors ba ON ( ba.book_id = b.book_id )
JOIN authors a ON ( ba.author_id = a.author_id )
WHERE a.author_name = '".$authorName."')";
             
             include './includes/helpers.php';
             $countResults = 0;
             if (isset($_GET['orderByAuthor'])) {
              $orderByAuthor = mysqli_real_escape_string($connection, $_GET['orderByAuthor']);
              $query = $query . 'ORDER BY author_name '.$orderByAuthor;
              $countResults=getBooks($connection, $query);
        }else if (isset($_GET['orderByTitle'])) {
              $orderByTitle = mysqli_real_escape_string($connection, $_GET['orderByTitle']);
              $query = $query . 'ORDER BY book_title '.$orderByTitle;
              $countResults=getBooks($connection, $query);
        }else{
            $countResults = getBooks($connection, $query);
        }
             if ($countResults == 0) {
                 echo '<br><br>Няма намерени книги с автор: "'.$authorName.'".';
             }
             
             
        }  else {
           
            header('Location: index.php');
        }
}  else {
    header('Location: index.php');
}
    include './includes/footer.php';    
?>
