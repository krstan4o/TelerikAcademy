[{"firstname":"Georgi","lastname": "Georgiev", "nickname": "Joro Mentata"},
{"firstname":"Peter","lastname": "Petrov", "nickname": "Pesho Vodkata"},
{"firstname":"Natalie","lastname": "Hoofman", "nickname": "Natka Kopitoto"},
{"firstname":"Ivan","lastname": "Ivanov", "nickname": "Bai Ivan"},
{"firstname":"Cvetana","lastname": "Cvetanova", "nickname": "Ceca Mecata"}]