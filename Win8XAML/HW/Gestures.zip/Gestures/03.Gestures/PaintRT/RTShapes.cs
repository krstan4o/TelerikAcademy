﻿using System;
using System.Linq;

namespace PaintRT
{
	enum RTShapes
	{
		Line = 52,
		Circle = 0,
		Square = -55
	}
}