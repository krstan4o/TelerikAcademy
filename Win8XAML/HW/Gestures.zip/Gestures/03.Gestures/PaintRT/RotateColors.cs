﻿namespace PaintRT
{
	enum RTColors
	{
		Red = 0,
		Green = 90,
		Blue = 180,
		Black = 270
	}
}