﻿using System;
using System.Linq;

namespace ViewModels
{
    public class OSViewModel
    {
        public string Name { get; set; }

        public string Version { get; set; }

        public string Manufacturer { get; set; }
    }
}
