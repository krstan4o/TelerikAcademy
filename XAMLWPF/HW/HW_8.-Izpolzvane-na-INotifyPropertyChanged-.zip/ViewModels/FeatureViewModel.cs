﻿using System;
using System.Linq;

namespace ViewModels
{
    public class FeatureViewModel
    {
        public string Name { get; set; }

        public string Value { get; set; }

    }
}
