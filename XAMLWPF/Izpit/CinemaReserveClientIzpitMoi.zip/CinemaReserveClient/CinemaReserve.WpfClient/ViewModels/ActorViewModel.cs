﻿using System;

namespace CinemaReserve.WpfClient.ViewModels
{
    public class ActorViewModel
    {
        public int Id{ get; set; }

        public string FullName { get; set; }
    }
}
