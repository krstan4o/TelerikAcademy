﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CinemaReserve.WpfClient.ViewModels
{
    public interface IPageViewModel
    {
        string Name { get; }
    }
}
