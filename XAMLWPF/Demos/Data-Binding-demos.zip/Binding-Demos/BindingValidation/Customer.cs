﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BindingValidation
{
    class Customer
    {
        public string Name { get; set; }
        public string EGN { get; set; }
        public DateTime DOB { get; set; }
        public int Code { get; set; }
    }
}
