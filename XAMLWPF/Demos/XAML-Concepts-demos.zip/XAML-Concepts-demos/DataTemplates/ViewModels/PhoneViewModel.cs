﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DataTemplates.ViewModels
{
   public class PhoneViewModel
    {
        public string Model { get; set; }

        public string Vendor { get; set; }
    }
}
