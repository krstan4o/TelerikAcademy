namespace PhonesStore.ViewModels
{
    public class OperatingSystemViewModel
    {
        public string Name { get; set; }

        public string Version { get; set; }

        public string Manufacturer { get; set; }
    }
}