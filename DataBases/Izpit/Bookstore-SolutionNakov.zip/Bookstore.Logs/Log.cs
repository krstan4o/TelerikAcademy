﻿namespace Bookstore.Logs
{
    using System;

    public class Log
    {
        public int LogId { get; set; }

        public DateTime DateCreatedOn { get; set; }

        public string LogContent { get; set; }
    }
}
