﻿using System;
using System.Data.Entity;

namespace Bookstore.Logs
{
    public class LogsContext : DbContext
    {
        public LogsContext()
			: base("LogsContext")
        {
        }

        public DbSet<Log> Logs { get; set; }

		public static void AppendToLogs(string text)
		{
			LogsContext context = new LogsContext();
			Log log = new Log();
			log.DateCreatedOn = DateTime.Now;
			log.LogContent = text;
			context.Logs.Add(log);
			context.SaveChanges();
		}
    }
}
