Уважаеми оценителю,

Изтрил съм .git папките, тъй като бях комитнал пакетите в тях и архивът стана твърде голям. И двете задачи работя, предполагам че ще се ориентираш бързо ако разгледаш контролерите:

- CodeJewels\CodeJewels.Service\Controllers\JewelsController.cs 

- MailHook\MailHook\Controllers\HookController.cs.

В "service hook email.png" има скрийншот на AppHarbor-ски service hook имейл.

Приятно проверяване :-)

