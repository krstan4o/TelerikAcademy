using System.ComponentModel.DataAnnotations;

namespace CodeJewels.Model
{
    public class Jewel
    {
        [Key]
        public int JewelId { get; set; }

        public virtual Category Category { get; set; }

        public string Author { get; set; }

        public int Rating { get; set; }

        [DataType("nfulltext")]
        public string SourceCode { get; set; }

        public Jewel()
        {
            this.Rating = 0;
        }
    }
}