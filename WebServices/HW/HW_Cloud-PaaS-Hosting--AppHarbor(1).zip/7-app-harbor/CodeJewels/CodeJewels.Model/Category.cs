﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;

namespace CodeJewels.Model
{
    public class Category
    {
        [Key]
        public int CategoryId { get; set; }

        public string Name { get; set; }

        public virtual ICollection<Jewel> CodeJewels { get; set; }

        public Category()
        {
            this.CodeJewels = new HashSet<Jewel>();
        }
    }
}
