﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web;
using System.Web.Http;
using CodeJewels.Model;
using CodeJewels.Data;

namespace CodeJewels.Service.Controllers
{
    public class CodeJewelsController : ApiController
    {
        private CodeJewelsContext db = new CodeJewelsContext();

  
        // GET api/Jewel
        public IEnumerable<Jewel> GetJewels()
        {
            return db.CodeJewels.AsEnumerable();
        }

        // GET api/Jewel/5
        public Jewel GetJewel(int id)
        {
            return db.CodeJewels.Find(id).IfNull404();
        }

        [HttpGet]
        [ActionName("searchCategory")]
        public IEnumerable<Jewel> GetJewelsByCategory(string categoryName)
        {
            return db.Categories
                     .FirstOrDefault(x => x.Name.Contains(categoryName))
                     .IfNull404()
                     .CodeJewels;
        }

        [HttpGet]
        [ActionName("searchCode")]
        public IEnumerable<Jewel> GetJewelsBySourceCode(string code)
        {
            return
                db.CodeJewels
                  .Where(x => x.SourceCode.Contains(code))
                  .ToList();

        }

        [HttpPost]
        [ActionName("voteUp")]
        public HttpResponseMessage UpVote([FromBody]int id)
        {
            var jewel = db.CodeJewels.Find(id);
            if (jewel == null)
                return Request.CreateResponse(HttpStatusCode.NotFound);

            jewel.Rating++;
            db.SaveChanges();

            return Request.CreateResponse(HttpStatusCode.OK);
        }

        [HttpPost]
        [ActionName("voteDown")]
        public HttpResponseMessage DownVote([FromBody]int id)
        {
            var jewel = db.CodeJewels.Find(id).IfNull404();

            jewel.Rating -= 1;
            if (jewel.Rating <= -2)
            {
                db.CodeJewels.Remove(jewel);
            }
            else
            {
                db.Entry(jewel).State = EntityState.Modified;
            }

            db.SaveChanges();

            return Request.CreateResponse(HttpStatusCode.OK);
        }

        // PUT api/Jewel/5
        public HttpResponseMessage PutJewel(int id, Jewel jewel)
        {
            if (ModelState.IsValid && jewel != null && id == jewel.JewelId)
            {
                db.Entry(jewel).State = EntityState.Modified;

                try
                {
                    db.SaveChanges();
                }
                catch (DbUpdateConcurrencyException)
                {
                    return Request.CreateResponse(HttpStatusCode.NotFound);
                }

                return Request.CreateResponse(HttpStatusCode.OK);
            }
            else
            {
                return Request.CreateResponse(HttpStatusCode.BadRequest);
            }
        }

        // POST api/Jewel
        public HttpResponseMessage PostJewel(Jewel jewel, string categoryName)
        {
            if (ModelState.IsValid && jewel != null)
            {
                var category = db.Categories
                                 .FirstOrDefault(x => x.Name == categoryName);
                if (category == null)
                    category = new Category();
                jewel.Category = category;
                jewel.Rating = 0;
                db.CodeJewels.Add(jewel);
                db.SaveChanges();

                HttpResponseMessage response = Request.CreateResponse(HttpStatusCode.Created, jewel);
                return response;
            }
            else
            {
                return Request.CreateResponse(HttpStatusCode.BadRequest);
            }
        }

        // DELETE api/Jewel/5
        public HttpResponseMessage DeleteJewel(int id)
        {
            Jewel jewel = db.CodeJewels.Find(id).IfNull404();

            db.CodeJewels.Remove(jewel);

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateConcurrencyException)
            {
                return Request.CreateResponse(HttpStatusCode.NotFound);
            }

            return Request.CreateResponse(HttpStatusCode.NoContent, jewel);
        }

        protected override void Dispose(bool disposing)
        {
            db.Dispose();
            base.Dispose(disposing);
        }
    }
}