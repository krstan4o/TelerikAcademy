﻿using System;
using System.Data.Entity;
using System.Linq;
using CodeJewels.Model;

namespace CodeJewels.Data
{
    public class CodeJewelsContext : DbContext
    {
        public DbSet<Jewel> CodeJewels { get; set; }
        public DbSet<Category> Categories { get; set; }
    }
}
