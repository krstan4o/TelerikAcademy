﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Mail;
using System.Text;
using System.Web.Http;
using System.Web.Management;
using Typesafe.Mailgun;

namespace MailHook.Controllers
{
    public class HookController : ApiController
    {
        public string Get()
        {
            return "All systems online! Messages:\n" + messages.ToString();
        }
        static StringBuilder messages = new StringBuilder();
        public void Post([FromBody] RootObject ro)
        {
            try
            {
                messages.AppendLine(ro.build.url);
                var sc = new SmtpClient
                {
                    Host = ConfigurationManager.AppSettings["MAILGUN_SMTP_HOST"],
                    Port = int.Parse(ConfigurationManager.AppSettings["MAILGUN_SMTP_PORT"])
                };
                sc.Credentials = new NetworkCredential(
                    ConfigurationManager.AppSettings["MAILGUN_SMTP_LOGIN"],
                    ConfigurationManager.AppSettings["MAILGUN_SMTP_PASSWORD"]);

                var msg = new MailMessage("commit@mailgun.org", "myAddress@gmail.com")
                {
                    Subject = "AppHarbor COMMIT: " + ro.application.name,
                    Body = ro.build.status + ": " + ro.build.branch.commit.message
                };
                sc.Send(msg);
                // var mailClient = new MailgunClient("samples.mailgun.org", ConfigurationManager.AppSettings["MAILGUN_API_KEY"]);
                // var mailClient = new MailgunClient("staafl.mailgun.org", ConfigurationManager.AppSettings["MAILGUN_API_KEY"]);
                // mailClient.SendMail(msg);
            }
            catch (Exception ex)
            {
                new LogEvent(ex.ToString()).Raise();
            }
        }

        public class LogEvent : WebRequestErrorEvent
        {
            public LogEvent(string message)
                : base(null, null, 100001, new Exception(message))
            {
            }
        }


        public class Application
        {
            public string name { get; set; }
            public string slug { get; set; }
            public string url { get; set; }
        }

        public class Commit
        {
            public string id { get; set; }
            public string message { get; set; }
        }

        public class Branch
        {
            public string name { get; set; }
            public Commit commit { get; set; }
        }

        public class Build
        {
            public string id { get; set; }
            public Branch branch { get; set; }
            public string status { get; set; }
            public string url { get; set; }
        }

        public class RootObject
        {
            public Application application { get; set; }
            public Build build { get; set; }
        }

    }
}